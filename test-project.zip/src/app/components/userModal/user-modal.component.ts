import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormControl, Validators } from '@angular/forms';


@Component({
    selector: 'app-user-modal',
    templateUrl: './user-modal.component.html',
    styleUrls: ['./user-modal.component.scss']
})

export class UserModalComponent implements OnInit {
    isNew = true;
    userId = null;

    userForm = new FormGroup({
        id: new FormControl('0', []),
        title: new FormControl('', [Validators.required]),
        category: new FormControl('', [Validators.required]),
        description: new FormControl('', [Validators.required]),
        stock: new FormControl('', [Validators.required]),

    });
    
    constructor(
        public dialogRef: MatDialogRef<UserModalComponent>, 
        @Inject(MAT_DIALOG_DATA) public data: any) {}

    ngOnInit(): void {
        if (this.data.user) {
            this.isNew = false;

            this.userId = this.data.user.id;

            this.userForm.setValue({
                id: this.data.user.id ?? '',
                title: this.data.user.title ?? '',
                category: this.data.user.category ?? '',
                description: this.data.user.description ?? '',
                stock: this.data.user.stock?? '',
   
            });
        }
    }

    save() {
        if (this.userForm.valid) {
            this.dialogRef.close(this.userForm.value);
        } else {
            alert('Invalid form');
        }
    }
}
