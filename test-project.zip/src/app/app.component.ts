import { Component } from '@angular/core';
import { OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { UserModalComponent } from './components/userModal/user-modal.component';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})


export class AppComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name','date', 'type', 'weight', 'symbol', 'options'];
  dataSource : any [];
  startDate = new Date(1990, 0, 1);
  postId: any;
  
  constructor(public dialog: MatDialog, private httpClient: HttpClient,) { }
  
  @ViewChild(MatPaginator) paginator: MatPaginator;
  getProducto() {
    return this.httpClient.get('https://dummyjson.com/products');
  }

  ngOnInit(): void {
    // this.dataSource.paginator = this.paginator;
    // this.httpClient
    //   .post<any>('https://dummyjson.com/products/add', {
    //     title: 'Prueba',
    //     category:'Celular',
    //     description:'Uno'
    //   })
    //   .subscribe((data) => {
    //     this.postId = data;
    //     this.dataSource.push(data);
    //     console.log(this.postId)
    //   });
      this.postId
      this.dataSource
    this.getProducto().subscribe((posts: any) => {

      this.dataSource = posts.products;
      console.log(this.dataSource)
    }
    )
  }

  newUser() {
    this.openUserModal();
  }

  editUser(user: any) {
    console.log(user)
    this.openUserModal(user);
  }
 delete(data: any){
   const headers = { 'Authorization': 'Bearer my-token', 'My-Custom-Header': 'foobar' };
   this.httpClient.delete(`https://dummyjson.com/products/${data.id}`, )
     .subscribe(() => data
     );
     this.dataSource
     console.log(data)
     console.log(this.dataSource)
 }
  openUserModal(user: any = null) {
    const dialogRef = this.dialog.open(UserModalComponent, {
      width: '460px',
      height: '580px',      
      data: {
        user: user
      }
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        this.saveUser(result);
      }
    })
  }
 
  saveUser(data: any) {
    if (data.id == '0') {
      
      // data.id = 101;
      this.httpClient
        .post<any>('https://dummyjson.com/products/add', {
          title: data.title,
          category: data.category,
          description: data.description,
          stock: data.stock
        })
        .subscribe((data) => {
          this.postId = data;
          this.dataSource.push(data);
          console.log(this.postId)
          this.dataSource
          this.postId
        });
      console.log(this.dataSource)

      console.log(data)


    } else {

      const body = {
        title: data.title ,
        category: data.category,
        description: data.description,
        stock: data.stock 
      };
      this.httpClient.put<any>(`https://dummyjson.com/products/${data.id}`, body)
        .subscribe(data => this.postId = data.id);
      this.dataSource.push(data);
      console.log(this.dataSource)
      this.dataSource

    }
  }
}